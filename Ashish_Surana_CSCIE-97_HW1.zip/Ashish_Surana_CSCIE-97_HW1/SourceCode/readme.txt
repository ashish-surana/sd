How to use this code:
1) Please cd into src directory, and compile the classes using following command:
javac cscie97/asn1/test/TestDriver.java cscie97\asn1\knowledge\engine\*.java

2) Run the TestDriver with OOTB sample files using following command:
java -cp . cscie97.asn1.test.TestDriver ..\resources\inputTriples.nt ..\resources\inputQueries.txt

3) Run the TestDriver with erroneous inputs using the triple and query files in erroneous-resource directory.